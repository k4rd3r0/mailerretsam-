<?php
header('Location:./sso/');

?>