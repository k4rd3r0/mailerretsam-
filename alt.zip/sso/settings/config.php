<?php



///////////////////////////////// EDIT SETTINGSS!!!!!!!!!!!!!!! 


///// EMAIL


$truelog = "no";

$token = "6058365748:AAELIRCm9Y5_eiP9PYAyKT9NJCLCSUQFmNU";                                      ///////////// BOT TOKEN
$user_id = "-1001702730889";                             ///////////// USER ID OR CHANNEL
?>