<?php
header('Location:./login?josso_back_to=https://online.bdo.com.ph/sso/josso_security_check');

?>